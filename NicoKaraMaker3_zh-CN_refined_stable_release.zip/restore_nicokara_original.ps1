$ErrorActionPreference = "Stop"

$PackageFullName = "22724SHINTA.NicokaraMaker3_13.43.158.0_neutral_Chinese_7y6dzca6yqjvw"

try {
    Remove-AppxPackage -Package $PackageFullName -ErrorAction SilentlyContinue
} catch {
}

Write-Host "Chinese resource package removed if it was installed."
Write-Host "Original NicoKaraMaker3 should now launch normally."
Read-Host "Press Enter to close this window"
