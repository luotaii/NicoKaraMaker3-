param(
    [switch]$SkipCertificateImport
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogPath = Join-Path $ScriptDir "install_nicokara_zh_refined_stable.log"

trap {
    Write-Host ""
    Write-Host "NicoKaraMaker3 stable refined Chinese package installation failed." -ForegroundColor Red
    Write-Host ""
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Write-Host "Error log saved to:" -ForegroundColor Yellow
    Write-Host $LogPath -ForegroundColor Yellow
    try {
        $_ | Out-String | Add-Content -LiteralPath $LogPath -Encoding UTF8
    } catch {
    }
    Read-Host "Press Enter to close this window"
    exit 1
}

"==== NicoKaraMaker3 stable refined zh-CN install $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ====" | Set-Content -LiteralPath $LogPath -Encoding UTF8

$IsAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator
)

if (-not $IsAdmin) {
    $PowerShellExe = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
    if (-not (Test-Path -LiteralPath $PowerShellExe)) {
        $PowerShellExe = Join-Path $PSHOME "powershell.exe"
    }

    $ArgsList = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", "`"$PSCommandPath`""
    )
    if ($SkipCertificateImport) {
        $ArgsList += "-SkipCertificateImport"
    }
    Start-Process -FilePath $PowerShellExe -ArgumentList $ArgsList -Verb RunAs
    exit
}

$CertPath = Join-Path $ScriptDir "NicoKaraMaker3_zh_test.cer"
$PackagePath = Join-Path $ScriptDir "NicoKaraMaker3_13.43.158.0_zh-CN_refined_stable.msix"
$KnownResourcePackageFullName = "22724SHINTA.NicokaraMaker3_13.43.158.0_neutral_Chinese_7y6dzca6yqjvw"

if (-not (Test-Path -LiteralPath $PackagePath)) {
    throw "Package not found: $PackagePath"
}

if (-not $SkipCertificateImport) {
    if (-not (Test-Path -LiteralPath $CertPath)) {
        throw "Certificate not found: $CertPath"
    }
    Import-Certificate -FilePath $CertPath -CertStoreLocation Cert:\LocalMachine\Root | Out-Null
    Import-Certificate -FilePath $CertPath -CertStoreLocation Cert:\LocalMachine\TrustedPeople | Out-Null
    Import-Certificate -FilePath $CertPath -CertStoreLocation Cert:\CurrentUser\Root | Out-Null
    Import-Certificate -FilePath $CertPath -CertStoreLocation Cert:\CurrentUser\TrustedPeople | Out-Null
}

Get-Process NicoKaraMaker3 -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue

$ExistingPackages = @()
try {
    $ExistingPackages += Get-AppxPackage -Name "22724SHINTA.NicokaraMaker3" | Where-Object {
        $_.IsResourcePackage -and $_.ResourceId -eq "Chinese"
    }
} catch {
}

try {
    $ExistingPackages += Get-AppxPackage -AllUsers -Name "22724SHINTA.NicokaraMaker3" | Where-Object {
        $_.IsResourcePackage -and $_.ResourceId -eq "Chinese"
    }
} catch {
}

foreach ($Package in $ExistingPackages) {
    Remove-AppxPackage -Package $Package.PackageFullName -ErrorAction SilentlyContinue
    Remove-AppxPackage -Package $Package.PackageFullName -AllUsers -ErrorAction SilentlyContinue
}

Remove-AppxPackage -Package $KnownResourcePackageFullName -ErrorAction SilentlyContinue
Remove-AppxPackage -Package $KnownResourcePackageFullName -AllUsers -ErrorAction SilentlyContinue

try {
    Add-AppxPackage -Path $PackagePath -ForceApplicationShutdown
} catch {
    if ($_.Exception.Message -like "*0x80073CFB*" -or $_.Exception.Message -like "*same identity*") {
        Add-AppxPackage -Path $PackagePath -ForceApplicationShutdown -ForceUpdateFromAnyVersion
    } else {
        throw
    }
}

Write-Host "NicoKaraMaker3 stable refined Chinese resource package installed."
"Installed successfully." | Add-Content -LiteralPath $LogPath -Encoding UTF8
Read-Host "Install finished. Press Enter to close this window"
