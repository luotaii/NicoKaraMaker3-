@echo off
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "SCRIPT=%~dp0restore_nicokara_original.ps1"

if not exist "%PS%" (
  echo Cannot find Windows PowerShell: %PS%
  pause
  exit /b 1
)

if not exist "%SCRIPT%" (
  echo Cannot find restore script: %SCRIPT%
  pause
  exit /b 1
)

"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
