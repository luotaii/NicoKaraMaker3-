NicoKaraMaker3 简体中文临时资源包

说明：
这是非官方临时简体中文资源包，仅用于等待上游合并中文翻译期间临时使用。
请先从 Microsoft Store 安装 NicoKaraMaker3 原版。本压缩包不包含原软件本体。

适用版本：
NicoKaraMaker3 13.43.158.0

安装：
双击“双击安装_NicoKaraMaker3_中文精翻可用版.cmd”，按提示同意管理员授权。

恢复原版：
双击“双击恢复_NicoKaraMaker3_原版.cmd”。

包含文件：
- NicoKaraMaker3_13.43.158.0_zh-CN_refined_stable.msix：中文资源包
- NicoKaraMaker3_zh_test.cer：安装资源包所需的测试证书公钥
- install_nicokara_zh_refined_stable.ps1：安装脚本
- 双击安装_NicoKaraMaker3_中文精翻可用版.cmd：双击安装入口
- restore_nicokara_original.ps1：恢复原版脚本
- 双击恢复_NicoKaraMaker3_原版.cmd：双击恢复入口

注意：
不要公开发布 .pfx 私钥证书。
不要公开发布从 Microsoft Store 下载的原始完整安装包或解包后的软件本体。
