@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "SCRIPT=%SCRIPT_DIR%install_nicokara_zh_refined_stable.ps1"

if not exist "%PS%" (
  echo Cannot find Windows PowerShell: %PS%
  pause
  exit /b 1
)

if not exist "%SCRIPT%" (
  echo Cannot find install script: %SCRIPT%
  pause
  exit /b 1
)

"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
if errorlevel 1 (
  echo.
  echo Installation failed. Check install_nicokara_zh_refined_stable.log in this folder.
  pause
)
