@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%install_nicokara_zh_refined_stable.ps1"
if errorlevel 1 (
  echo.
  echo Installation failed. Check install_nicokara_zh_refined_stable.log in this folder.
  pause
)
