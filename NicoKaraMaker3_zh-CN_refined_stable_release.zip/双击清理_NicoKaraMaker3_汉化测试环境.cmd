@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "SCRIPT=%SCRIPT_DIR%cleanup_nicokara_zh_test_environment.ps1"

if not exist "%PS%" (
  echo Cannot find Windows PowerShell: %PS%
  pause
  exit /b 1
)

if not exist "%SCRIPT%" (
  echo Cannot find cleanup script: %SCRIPT%
  pause
  exit /b 1
)

"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -KeepAppClosed
if errorlevel 1 (
  echo.
  echo Cleanup failed. Check cleanup_nicokara_zh_test_environment.log in this folder.
  pause
)
